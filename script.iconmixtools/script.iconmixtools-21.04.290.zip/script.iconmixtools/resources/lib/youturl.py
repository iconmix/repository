#!/usr/bin/env python



try:
 
 from urllib.request import urlopen as Uurlopen
 from urllib.parse import parse_qs
except:
  from urllib2 import urlopen as Uurlopen
  from urlparse import parse_qs

from os.path import basename
import sys,json




class YTURL():
    def __init__(self):
        self.youtubeQueryURL = 'http://youtube.com/get_video_info?&video_id=%s&el=detailpage&ps=default&eurl=&gl=US&hl=en'
        self.videoURLListKey = 'url_encoded_fmt_stream_map'
        self.videoIDKeys = [ 'v', 'video_id' ]
        self.videoItagQualityOrder = [ 38, 37, 22, 45, 44, 35, 18, 34, 43, 5, 17 ]
        self.allowedVideoIDCharacters = '-_abcdefghijklmnopqrstuvwxyz0123456789'

    def getVideoItags(self, videoID):
        """ Returns the available itags and their associated URLs as a list. """
        availableFormats = {}
        try:
          
          response=Uurlopen(self.youtubeQueryURL % videoID).read().decode()
          
          parsedResponse = parse_qs(response)
          data=json.loads(parsedResponse.get("player_response")[0])
          streamingData=data.get("streamingData")
          formats=streamingData.get("formats")
          for videoFormat in formats:
                  availableFormats[int(videoFormat['itag'])] = videoFormat['url']
                
        except:
            return False
        return availableFormats

    def checkIsValidItag(self, itag):
        """ Checks that all arguments are known itags. """
        if itag not in self.videoItagQualityOrder:
            return False
        else:
            return True

    def getPreferredItagOrder(self, preferredItags):
        """ Determines and returns the preferred video itag sorting.
            If argv has a length of 3, this returns a tuple, otherwise, it
            returns a list. """

        if len(preferredItags) == 1:
            v = self.videoItagQualityOrder
            return zip(*sorted(enumerate(v),key=lambda i_x:abs(v.index(preferredItags[0])-i_x[0])))[1]
        elif len(preferredItags) > 1:
            for itag in preferredItags:
                self.videoItagQualityOrder.remove(itag)
            return preferredItags + self.videoItagQualityOrder
        else:
            return self.videoItagQualityOrder

    def checkIsValidVideoID(self, videoID):
        """ Checks that a video ID is syntactically valid. """
        if len(videoID) != 11:
            return False

        for c in videoID:
            if c.lower() not in self.allowedVideoIDCharacters:
                return False
        return True

    def stripYouTubeURL(self, url):
        """ Strips a YouTube URL to the video ID. """
        if '?' in url:
            url = url[url.index('?') + 1:]
            urlPost = parse_qs(url)
            for key in self.videoIDKeys:
                if key in urlPost:
                    return urlPost[key][0]

        if url.startswith('http://'):
            url = url[7:]
        elif url.startswith('https://'):
            url = url[8:]

        if url.startswith('www.'):
            url = url[4:]

        if url.startswith('youtu.be/'):
            return url[9:]
        elif url.startswith('youtube.com/v/'):
            return url[14:]

        return url

def getyoutubeurl(YoutubeID=None):  
    URLYoutube=None
    y = YTURL()
    videoID = y.stripYouTubeURL(YoutubeID)
    if not y.checkIsValidVideoID(videoID):
        return None  
        
    #preferredItags = map(int, sys.argv[2:])
    preferredItags = []
    availableFormats = y.getVideoItags(videoID)
    

    if availableFormats is not False:
        for itag in y.getPreferredItagOrder(preferredItags):
            if itag in availableFormats:
                #print availableFormats[itag]
                URLYoutube=availableFormats[itag]
                break

    else:
        return None
    
    return URLYoutube