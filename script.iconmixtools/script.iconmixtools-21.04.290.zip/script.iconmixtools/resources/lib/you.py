import youturl
import sys,os

print(youturl.getyoutubeurl('https://www.youtube.com/watch?v=uNodPnBNR24'))